﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		Tower.cs
//	Description:    File containing a class representing the entire tower in the Tower of Hanoi game.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Sunday, April 5, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3Hanoi {

    /// <summary>
    /// The Pole class represents the entire tower in the Tower of Hanoi game. It contains the algorithm to solve the puzzle.
    /// </summary>
    class Tower {
        private const int poleCount = 3;
        public static List<Pole> poles = new List<Pole>(poleCount);
        private static int N; // The number of disks in the Pole objects
        public static int iterator = 0;

        /// <summary>Initializes values for the Tower class.</summary>
        public Tower() {
            N = 0;
            iterator = 0;
        }

        /// <summary>Initializes the pole values for the Tower class.</summary>
        /// <param name="numDisks">The number of disks.</param>
        public Tower(int numDisks) {
            N = numDisks;

            Pole p1 = new Pole();
            p1.SetupDisks(numDisks);
            poles.Add(p1);

            Pole p2 = new Pole();
            p2.SetupDisks(0);
            poles.Add(p2);

            Pole p3 = new Pole();
            p3.SetupDisks(0);
            poles.Add(p3);

        }

        /// <summary>Returns whether the number of disks in the tower is even or odd.</summary>
        /// <returns>A boolean value representing whether the number of moves is even or odd.</returns>
        public static bool EvenOdd(int diskNumber) {
            if (diskNumber % 2 == 0) {
                return true;
            } else {
                return false;
            }
        }

        /// <summary>Returns the number of moves to solve the puzzle.</summary>
        /// <returns>Number of moves.</returns>
        public static double NumberMoves() {
            return Math.Pow(2, N) - 1;
        }

        /// <summary>A method that solves the tower through a simple algorithm. It moves one disk per iteration while maintaining the rules until the puzzle is complete.</summary>
        /// <param name="diskNumber">The number of disks in the game.</param>
        /// <param name="iteration">The current step in the game.</param>
        /// <param name="sourcePole">The first pole in the game.</param>
        /// <param name="auxiliaryPole">The second pole in the game.</param>
        /// <param name="destinationPole">The third pole in the game.</param>
        public static void TowerSolver(int diskNumber, int iteration, Pole sourcePole, Pole auxiliaryPole, Pole destinationPole) {

                if(EvenOdd(diskNumber)) { // If the current move is an even number, then change the direction the disk will move.
                    Pole swapPole = new Pole(); // Temporary object to hold pole positions.
                    Swap(swapPole, auxiliaryPole, destinationPole); // Swap method for the auxiliary pole and destination pole.
                }
                if(iteration % 3 == 1) { // If the iteration number is an odd number that is not divisible by 3. In that case, do the first move.
                    DiskTransfer(sourcePole, destinationPole);
                } else if(iteration % 3 == 2) { // If the iteration number is a even number that is not divisible by 3. In this case, the second move.
                    DiskTransfer(sourcePole, auxiliaryPole);
                } else {                        // If the iteration is a number divisible by 3. In this case, the third move.
                    DiskTransfer(auxiliaryPole, destinationPole);
                }
        }


        /// <summary>Swaps the specified poles in the Tower.</summary>
        /// <param name="swapPole">The swap pole.</param>
        /// <param name="auxiliaryPole">The auxiliary pole.</param>
        /// <param name="destinationPole">The destination pole.</param>
        private static void Swap(Pole swapPole, Pole auxiliaryPole, Pole destinationPole) {
            swapPole = auxiliaryPole; // Store auxPole in swapPole.
            auxiliaryPole = destinationPole; // Store destinationPole in auxPole.
            destinationPole = swapPole; // Store swapPole in destinationPole.
            // Swap complete.
        }


        /// <summary>Transfers the disks. This method is called once for every move and will make a decision on which disk to move in the pole.</summary>
        /// <param name="firstPole">The first pole in the movement of the disk.</param>
        /// <param name="secondPole">The second pole in the movement of the disk.</param>
        private static void DiskTransfer(Pole firstPole, Pole secondPole) {
            if (firstPole.Count() == 0) { // If the first pole is empty, transfer the disk from the second pole to the first pole.
                firstPole.Push(secondPole.Pop());
            } else if (secondPole.Count() == 0) { // If the second pole is empty, transfer the disk from the first pole to the second pole.
                secondPole.Push(firstPole.Pop());
            } else if (secondPole.Peek().Size > firstPole.Peek().Size) { // If the second pole has a size greater than the first pole, move the disk from the second pole to the first pole.
                secondPole.Push(firstPole.Pop());
            } else {                            // If the second pole has a size smaller than the first pole, move the disk from the first pole to the second pole.
                firstPole.Push(secondPole.Pop());
            }
            // Return to TowerSolver method.
        }

        /// <summary>Displays a single specified pole in the Tower.</summary>
        /// <param name="poleNum">The number of the pole to be displayed.</param>
        public void ToString(int poleNum) {
            Console.WriteLine(poles[poleNum].ToString());
        }

        /// <summary>Displays and represents the Tower object in string format.</summary>
        /// <returns>The formatted Tower string.</returns>
        public override string ToString() {
            Console.WriteLine(poles[0]);
            Console.WriteLine("-----------------------------------");
            Console.WriteLine(poles[1]);
            Console.WriteLine("-----------------------------------");
            Console.WriteLine(poles[1]);
            Console.WriteLine("-----------------------------------");

            return "";
        }

    }
}
