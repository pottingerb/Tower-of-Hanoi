﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		Disk.cs
//	Description:    File containing a class representing a single disk on a pole in the Tower of Hanoi game.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Sunday, April 5, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3Hanoi {

    /// <summary>
    /// The Disk class represents a single disk object in the Tower of Hanoi game. The class has a default, parameterized, and copy constructor. It overrides the default ToString method to represent the disk object.
    /// </summary>
    class Disk {

        public int Size;

        /// <summary> Initializes a new instance of the Disk class. </summary>
        public Disk() {
            Size = 1;
        }

        /// <summary> Initializes a new instance of the Disk class with a specified size.</summary>
        /// <param name="Size">The size of the disk.</param>
        public Disk(int Size) {
            this.Size = Size;
        }

        /// <summary> Copies a different instance of the Disk class to this instance.</summary>
        /// <param name="other">The other Disk object.</param>
        public Disk(Disk other) {
            this.Size = other.Size;
        }

        /// <summary>Displays and represents the Disk object in string format.</summary>
        /// <returns>The formatted Disk string.</returns>
        public override string ToString() {

            String displayDisk = "|" + Size;
            for (int i = 0; i < Size; i++) {
                displayDisk += "_";
            }
            displayDisk += "|";

            return displayDisk;
        }


    }
}
