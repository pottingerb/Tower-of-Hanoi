﻿/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		HanoiSplashScreen,Designer.cs
//	Description:    File containing a partial class that initializes components for the Hanoi Splash Screen.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Friday, April 10, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


namespace Project3Hanoi {
    partial class HanoiSplashScreen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.SplashBg = new System.Windows.Forms.PictureBox();
            this.beginBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SplashBg)).BeginInit();
            this.SuspendLayout();
            // 
            // SplashBg
            // 
            this.SplashBg.Image = global::Project3Hanoi.Properties.Resources.TowerOfHanoiSplashBg;
            this.SplashBg.Location = new System.Drawing.Point(-1, 0);
            this.SplashBg.Name = "SplashBg";
            this.SplashBg.Size = new System.Drawing.Size(802, 451);
            this.SplashBg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SplashBg.TabIndex = 0;
            this.SplashBg.TabStop = false;
            // 
            // beginBtn
            // 
            this.beginBtn.Location = new System.Drawing.Point(331, 374);
            this.beginBtn.Name = "beginBtn";
            this.beginBtn.Size = new System.Drawing.Size(122, 45);
            this.beginBtn.TabIndex = 1;
            this.beginBtn.Text = "Begin";
            this.beginBtn.UseVisualStyleBackColor = true;
            this.beginBtn.Click += new System.EventHandler(this.beginBtn_Click);
            // 
            // HanoiSplashScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.beginBtn);
            this.Controls.Add(this.SplashBg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "HanoiSplashScreen";
            this.Opacity = 0.5D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HanoiSplashScreen";
            ((System.ComponentModel.ISupportInitialize)(this.SplashBg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox SplashBg;
        private System.Windows.Forms.Button beginBtn;
    }
}