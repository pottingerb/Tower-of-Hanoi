﻿/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		HanoiSplashScreen.cs
//	Description:    File containing a partial class that handles events for the Tower of Hanoi Splash Screen.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Friday, April 10, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace Project3Hanoi {


    /// <summary>
    /// Class that handles events for the Tower of Hanoi Splash Screen. 
    /// </summary>
    public partial class HanoiSplashScreen : Form {

        private static Form Form1;


        /// <summary>Default constructor for the Hanoi Splash Screen.</summary>
        public HanoiSplashScreen() {
            InitializeComponent();

            Form1 = this;

            CloseTimer();
        }


        /// <summary>Handles the Click event of the beginBtn control. It closes the Hanoi Splash Screen.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void beginBtn_Click(object sender, EventArgs e) {
            this.Close();
        }


        /// <summary>Closes the form after 2.0 seconds of the method call.</summary>
        private void CloseTimer() {

            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
            t.Interval = 1500;
            t.Tick += new EventHandler(timer_Tick);
            t.Start();
        }


        /// <summary>Handles the Tick event of the timer control. It closes the Hanoi Splash Screen.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void timer_Tick(object sender, EventArgs e) {
            this.Close();
        }
    }
}
