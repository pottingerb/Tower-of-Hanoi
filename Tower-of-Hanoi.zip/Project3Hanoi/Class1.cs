﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3Hanoi {
    class Class1 {

            //if(secondPole.Peek().Size > firstPole.Peek().Size) { // If the second pole has a size greater than the first pole, move the disk from the second pole to the first pole.
            //    secondPole.Push(firstPole.Pop());
            //else if (secondPole.Peek().Size<firstPole.Peek().Size) { // If the second pole has a size smaller than the first pole, move the disk from the first pole to the second pole.
            //    firstPole.Push(secondPole.Pop());
            //}
            //else if(firstPole.Count() == 0) { // If the first pole is empty, transfer the disk from the second pole to the first pole.
            //    firstPole.Push(secondPole.Pop());
            //} else { // If the second pole is empty, transfer the disk from the first pole to the second pole.
            //    secondPole.Push(firstPole.Pop());
            //}
            

            //if(firstPole.Count() == 0) { // If the first pole is empty, transfer the disk from the second pole to the first pole.
            //    firstPole.Push(secondPole.Pop());
            //} else if(secondPole.Count() == 0) { // If the second pole is empty, transfer the disk from the first pole to the second pole.
            //    secondPole.Push(firstPole.Pop());
            //} else if(secondPole.Peek().Size > firstPole.Peek().Size) { // If the second pole has a size greater than the first pole, move the disk from the second pole to the first pole.
            //    secondPole.Push(firstPole.Pop());
            //} else {                            // If the second pole has a size smaller than the first pole, move the disk from the first pole to the second pole.
            //    firstPole.Push(secondPole.Pop());
            //}

    }
}
