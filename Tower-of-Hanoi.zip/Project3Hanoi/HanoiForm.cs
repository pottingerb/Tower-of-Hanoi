﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		HanoiForm.cs
//	Description:    File containing a partial class holding all of the events for the Hanoi Form.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Tuesday, April 7, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3Hanoi {


    /// <summary>
    /// Class that handles all of the events for the Hanoi Form. It initializes components and handles their behavior.
    /// </summary>
    public partial class HanoiForm : Form {

        private static Tower t = new Tower(1); // Instance of Tower
        private static int diskNumberI = 1; // The disk size of the poles in the Tower
        private static int stepNumber = 0;
        private static int currentMove = 0;

        /// <summary>Initializes a new instance of the <see cref="HanoiForm" /> class. Initializes components.</summary>
        public HanoiForm() {
            InitializeComponent();
        }


        /// <summary>Handles the Load event of the HanoiForm control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void HanoiForm_Load(object sender, EventArgs e) {

        }


        /// <summary>Handles the Click event of the nextMoveBtn control. It initializes a new tower object.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void nextMoveBtn_Click(object sender, EventArgs e) {
            NextMove();
        }
        /// <summary>Handles the Click event of the nextMoveToolStripMenuItem control. Solves the Tower.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void nextMoveToolStripMenuItem_Click(object sender, EventArgs e) {
            NextMove();
        }


        /// <summary>Initiates the next move in the sequence for the Tower of Hanoi.</summary>
        private void NextMove() {
            if (currentMove < Tower.NumberMoves()) {
                stepNumber++;

                Tower.TowerSolver(diskNumberI, stepNumber, Tower.poles[0], Tower.poles[1], Tower.poles[2]);

                UpdatePoles();

                currentMove++;
                UpdateCurrentMove();
            }
        }

        /// <summary>Handles the Click event of the aboutToolStripMenuItem control. Opens a form that displays information about the Tower of Hanoi program.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e) {
            HanoiAboutBox hAboutBox = new HanoiAboutBox();
            hAboutBox.ShowDialog();
        }
            /// <summary>Handles the Click event of the startBtn control. It starts the Tower of Hanoi game.</summary>
            /// <param name="sender">The source of the event.</param>
            /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void startBtn_Click(object sender, EventArgs e) {
            StartGame();
        }

        /// <summary>Handles the Click event of the startToolStripMenuItem control. It starts the Tower of Hanoi game.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void startToolStripMenuItem_Click(object sender, EventArgs e) {
            StartGame();
        }


        /// <summary>Starts the Tower of Hanoi game. It initializes a Tower object with the number of disks specified by the user. It then updates the pole text boxes.</summary>
        private void StartGame() {

            string diskNumberS = "";
            if (numberOfDisksBox.Text != "") { // If the text box is not empty.
                try {
                    diskNumberS = numberOfDisksBox.Text;
                    diskNumberI = Int32.Parse(diskNumberS);
                } catch (FormatException e) {
                    throw new FormatException("Invalid input. Only numerical values allowed.", e);
                }
            }

            if (Tower.poles.Any()) { // If the poles hold disks.
                Tower.poles.Clear();
            }

            currentMove = 0;
            t = new Tower(diskNumberI);
            UpdatePoles();
            UpdateCurrentMove();
            UpdateTotalNumberOfMoves();
        }



        /// <summary>Handles the Click event of the quitToolStripMenuItem control. It exits the application.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void quitToolStripMenuItem_Click(object sender, EventArgs e) {
            System.Windows.Forms.Application.Exit();
        }


        /// <summary>Handles the Click event of the resetToolStripMenuItem control. It clears the text boxes and the Tower poles if they are initialized.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void resetToolStripMenuItem_Click(object sender, EventArgs e) {
            poleBox1.Clear();
            poleBox2.Clear();
            poleBox3.Clear();

            if (Tower.poles.Any()) { // If the poles hold disks.
                Tower.poles.Clear();
            }

            // Reset to default values
            t = new Tower(1);
            diskNumberI = 1;

            stepNumber = 0;
            currentMove = 0;
            UpdateCurrentMove();
            UpdateTotalNumberOfMoves();
        }


        /// <summary>Displays the total number of moves to solve the Tower of Hanoi. (2^N-1)</summary>
        private void UpdateTotalNumberOfMoves() {
            totalMovesStatusLabel.Text = Convert.ToString("Total Number of Moves: " + Tower.NumberMoves());
        }

        /// <summary>Updates the number representing the current move.</summary>
        private void UpdateCurrentMove() {
            currentMoveStatusLabel.Text = "Current Move: " + currentMove;
        }

        /// <summary>Updates the pole text boxes. It clears their old values and then updates them with new values.</summary>
        private void UpdatePoles() {

            if (diskNumberI != 1) { // if diskNumberI is not set to default value
                poleBox1.Clear();
                poleBox2.Clear();
                poleBox3.Clear();

                for (int i = 0; i < Tower.poles[0].Count(); i++) {
                    poleBox1.AppendText(Tower.poles[0].GetElement(i).ToString() + Environment.NewLine); // Adds the disks from the poles one at a time, then adds a newline.
                }

                for (int i = 0; i < Tower.poles[1].Count(); i++) {
                    poleBox2.AppendText(Tower.poles[1].GetElement(i).ToString() + Environment.NewLine);
                }

                for (int i = 0; i < Tower.poles[2].Count(); i++) {
                    poleBox3.AppendText(Tower.poles[2].GetElement(i).ToString() + Environment.NewLine);
                }
            }
        }

        }
}
