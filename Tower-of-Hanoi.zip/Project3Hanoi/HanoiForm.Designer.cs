﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		HanoiForm.cs
//	Description:    File containing a partial class that initializes the components for the Hanoi Form.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Tuesday, April 7, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace Project3Hanoi {
    partial class HanoiForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HanoiForm));
            this.nextMoveBtn = new System.Windows.Forms.Button();
            this.poleBox1 = new System.Windows.Forms.TextBox();
            this.poleBox2 = new System.Windows.Forms.TextBox();
            this.poleBox3 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nextMoveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.numberOfDisksLabel = new System.Windows.Forms.Label();
            this.numberOfDisksBox = new System.Windows.Forms.TextBox();
            this.startBtn = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.currentMoveStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.totalMovesStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // nextMoveBtn
            // 
            this.nextMoveBtn.Location = new System.Drawing.Point(326, 358);
            this.nextMoveBtn.Name = "nextMoveBtn";
            this.nextMoveBtn.Size = new System.Drawing.Size(100, 39);
            this.nextMoveBtn.TabIndex = 0;
            this.nextMoveBtn.Text = "Next Move";
            this.nextMoveBtn.UseVisualStyleBackColor = true;
            this.nextMoveBtn.Click += new System.EventHandler(this.nextMoveBtn_Click);
            // 
            // poleBox1
            // 
            this.poleBox1.Location = new System.Drawing.Point(144, 110);
            this.poleBox1.Multiline = true;
            this.poleBox1.Name = "poleBox1";
            this.poleBox1.ReadOnly = true;
            this.poleBox1.Size = new System.Drawing.Size(100, 217);
            this.poleBox1.TabIndex = 1;
            this.poleBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // poleBox2
            // 
            this.poleBox2.Location = new System.Drawing.Point(326, 110);
            this.poleBox2.Multiline = true;
            this.poleBox2.Name = "poleBox2";
            this.poleBox2.ReadOnly = true;
            this.poleBox2.Size = new System.Drawing.Size(100, 217);
            this.poleBox2.TabIndex = 2;
            this.poleBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // poleBox3
            // 
            this.poleBox3.Location = new System.Drawing.Point(509, 110);
            this.poleBox3.Multiline = true;
            this.poleBox3.Name = "poleBox3";
            this.poleBox3.ReadOnly = true;
            this.poleBox3.Size = new System.Drawing.Size(100, 217);
            this.poleBox3.TabIndex = 3;
            this.poleBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem,
            this.nextMoveToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(50, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(182, 30);
            this.startToolStripMenuItem.Text = "Start";
            this.startToolStripMenuItem.Click += new System.EventHandler(this.startToolStripMenuItem_Click);
            // 
            // nextMoveToolStripMenuItem
            // 
            this.nextMoveToolStripMenuItem.Name = "nextMoveToolStripMenuItem";
            this.nextMoveToolStripMenuItem.Size = new System.Drawing.Size(182, 30);
            this.nextMoveToolStripMenuItem.Text = "Next Move";
            this.nextMoveToolStripMenuItem.Click += new System.EventHandler(this.nextMoveToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(182, 30);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(182, 30);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(61, 29);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(146, 30);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // numberOfDisksLabel
            // 
            this.numberOfDisksLabel.AutoSize = true;
            this.numberOfDisksLabel.Location = new System.Drawing.Point(12, 44);
            this.numberOfDisksLabel.Name = "numberOfDisksLabel";
            this.numberOfDisksLabel.Size = new System.Drawing.Size(130, 20);
            this.numberOfDisksLabel.TabIndex = 6;
            this.numberOfDisksLabel.Text = "Number of Disks:";
            // 
            // numberOfDisksBox
            // 
            this.numberOfDisksBox.Location = new System.Drawing.Point(144, 41);
            this.numberOfDisksBox.Name = "numberOfDisksBox";
            this.numberOfDisksBox.Size = new System.Drawing.Size(366, 26);
            this.numberOfDisksBox.TabIndex = 7;
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(534, 38);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(75, 43);
            this.startBtn.TabIndex = 8;
            this.startBtn.Text = "Start";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.startBtn_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentMoveStatusLabel,
            this.totalMovesStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 420);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 30);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // currentMoveStatusLabel
            // 
            this.currentMoveStatusLabel.Name = "currentMoveStatusLabel";
            this.currentMoveStatusLabel.Size = new System.Drawing.Size(139, 25);
            this.currentMoveStatusLabel.Text = "Current Move: 0";
            // 
            // totalMovesStatusLabel
            // 
            this.totalMovesStatusLabel.Name = "totalMovesStatusLabel";
            this.totalMovesStatusLabel.Size = new System.Drawing.Size(218, 25);
            this.totalMovesStatusLabel.Text = "Total Number of Moves: 0";
            // 
            // HanoiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.startBtn);
            this.Controls.Add(this.numberOfDisksBox);
            this.Controls.Add(this.numberOfDisksLabel);
            this.Controls.Add(this.poleBox3);
            this.Controls.Add(this.poleBox2);
            this.Controls.Add(this.poleBox1);
            this.Controls.Add(this.nextMoveBtn);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "HanoiForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tower of Hanoi - Benjamin Pottinger";
            this.Load += new System.EventHandler(this.HanoiForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button nextMoveBtn;
        private System.Windows.Forms.TextBox poleBox1;
        private System.Windows.Forms.TextBox poleBox2;
        private System.Windows.Forms.TextBox poleBox3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nextMoveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label numberOfDisksLabel;
        private System.Windows.Forms.TextBox numberOfDisksBox;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel currentMoveStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel totalMovesStatusLabel;
    }
}

