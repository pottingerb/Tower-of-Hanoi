﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 3 - Tower of Hanoi
//	File Name:		Disk.cs
//	Description:    File containing a class representing a single pole in the tower in the Tower of Hanoi game.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Sunday, April 5, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3Hanoi {
    /// <summary>
    /// The Pole class represents a single pole object in the Tower of Hanoi game. The class adds disk objects to a pole and has all the basic functionality for a stack object.
    /// </summary>
    class Pole {

        //static void Main(string[] args) {
        //    Pole p = new Pole();
        //    p.SetupDisks();
        //    Console.WriteLine(p);
        //    Console.ReadKey();
        //}

        private Stack<Disk> pole = new Stack<Disk>();

        /// <summary>Adds the disks to a pole stack object.</summary>
        /// <param name="discCount">The number of disks to add to the pole object.</param>
        public void SetupDisks(int discCount) {
            for (int i = discCount; i > 0; i--) {
                Disk d = new Disk(i);
                pole.Push(d);
            }
        }

        /// <summary>Pushes the specified Disk to the array.</summary>
        /// <param name="d">The Disk object.</param>
        public void Push(Disk d) {
            pole.Push(d);
        }

        /// <summary>Pop the top Disk from the array.</summary>
        public Disk Pop() {
            return pole.Pop();
        }

        /// <summary>Peeks at the top Disk in the array.</summary>
        public Disk Peek() {
            return pole.Peek();
        }

        /// <summary>Returns the count of the pole object.</summary>
        /// <returns>The count of the pole object.</returns>
        public int Count() {
            return pole.Count;
        }


        /// <summary>Gets the element at the specified position.</summary>
        /// <param name="i">The position of the element.</param>
        /// <returns></returns>
        public string GetElement(int i) {
            return pole.ElementAt<Disk>(i).ToString();
        }


        /// <summary>Clears the instance.</summary>
        public void Clear() {
            pole.Clear();
        }

        /// <summary>Displays and represents the Pole object in string format.</summary>
        /// <returns>The formatted Pole string.</returns>
        public override string ToString() {

            foreach (Object disk in pole) {
                Console.WriteLine(disk);
            }

            return "";
        }

    }
}
